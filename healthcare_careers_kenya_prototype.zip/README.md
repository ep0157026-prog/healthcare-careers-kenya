# Healthcare Careers Kenya — prototype

A static, mobile-friendly prototype for a Kenyan healthcare jobs and opportunities platform.

## Important
The listings in this prototype are DEMO listings. Replace them with verified vacancies before publishing.

## Suggested next build
1. Real vacancy database/backend.
2. Employer submission form.
3. Admin approval dashboard.
4. M-Pesa/payment integration.
5. Email/WhatsApp alerts.
6. Employer accounts and paid featured listings.
7. SEO pages for healthcare job categories and Kenyan counties.

## Free deployment
GitHub Pages can host static HTML/CSS/JavaScript sites. Create a GitHub repository, upload `index.html`, and enable Pages.
